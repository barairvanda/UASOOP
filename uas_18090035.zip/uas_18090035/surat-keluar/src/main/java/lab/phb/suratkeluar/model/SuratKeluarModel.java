package lab.phb.suratkeluar.model;

import lombok.Data;

@Data
public class SuratKeluarModel {

    private String noSurat;
    private String tanggalSurat;
    private String perihal;
    private String tujuan;


}