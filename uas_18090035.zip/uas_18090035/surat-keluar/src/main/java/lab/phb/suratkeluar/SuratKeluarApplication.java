package lab.phb.suratkeluar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuratKeluarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuratKeluarApplication.class, args);
	}

}
