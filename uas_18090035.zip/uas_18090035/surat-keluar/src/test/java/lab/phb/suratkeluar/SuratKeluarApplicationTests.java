package lab.phb.suratkeluar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuratKeluarApplicationTests {

	@Test
	void contextLoads() {
	}

}
